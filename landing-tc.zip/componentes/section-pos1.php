<div class="row section-pos1 mt-5 mb-5">
    <div class="col-md-4">
        <div class="card">
            <center><img class="m-2" src="./img/icons8-nube-100.png" width="80" alt=""></center>
            <div class="card-body text-center">
                <h4 class=" mb-4 card-title">Sin descargas</h4>
                <p class=" mb-4 card-text">Accede desde cualquier dispositivo y lugar, manteniendo tu información segura en la nube.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <center> <img class="m-2" src="./img/icons8-soporte-en-línea-80.png" width="80" alt=""></center>
            <div class="card-body text-center">
                <h4 class=" mb-4 card-title">Soporte técnico</h4>
                <p class=" mb-4 card-text">Recibe asesoría gratuita de un equipo especializado a través de teléfono, correo electrónico o chat.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <center><img class="m-2" src="./img/icons8-actualizaciones-disponibles-80.png" width="80" alt=""></center>
            <div class="card-body text-center">
                <h4 class=" mb-4 card-title">Actualizaciones</h4>
                <p class=" mb-4 card-text">Disfruta de actualizaciones constantes sin costos adicionales y mantente siempre al día.</p>
            </div>
        </div>
    </div>
</div>